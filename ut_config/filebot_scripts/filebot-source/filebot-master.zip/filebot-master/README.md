# FileBot
[![SourceForge](https://img.shields.io/sourceforge/dt/filebot/filebot.svg)](https://sourceforge.net/projects/filebot/files/filebot/)
[![SourceForge](https://img.shields.io/sourceforge/dm/filebot/filebot.svg)](https://sourceforge.net/projects/filebot/files/filebot/)
[![SourceForge](https://img.shields.io/sourceforge/dw/filebot/filebot.svg)](https://sourceforge.net/projects/filebot/files/filebot/)
