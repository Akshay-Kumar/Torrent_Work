# Release Notes
Please see [Announcements and Releases](https://www.filebot.net/forums/viewforum.php?f=7) in the [FileBot Forums](https://www.filebot.net/forums/).

## Mac OS X
__FileBot for Mac__ is available on the [Mac App Store](https://itunes.apple.com/us/app/filebot/id905384638?mt=12&uo=6&at=1l3vupy&ct=readme).

## Ubuntu
__FileBot for Ubuntu__ is available on the [Ubuntu Software Center](https://apps.ubuntu.com/cat/applications/filebot/).

# SHA-256 checksums
```
