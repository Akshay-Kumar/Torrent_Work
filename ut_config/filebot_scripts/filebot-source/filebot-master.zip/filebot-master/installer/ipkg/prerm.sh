#!/bin/sh

# remove /bin symlink
rm -f /opt/bin/filebot
