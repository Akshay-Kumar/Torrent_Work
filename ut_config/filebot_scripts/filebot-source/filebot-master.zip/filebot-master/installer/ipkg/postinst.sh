#!/bin/sh

# create /bin symlink
ln -s -f /opt/share/filebot/bin/filebot.sh /opt/bin/filebot
