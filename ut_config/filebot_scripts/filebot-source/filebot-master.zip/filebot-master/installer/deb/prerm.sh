#!/bin/sh

# remove /bin symlink
rm -f /usr/bin/filebot
