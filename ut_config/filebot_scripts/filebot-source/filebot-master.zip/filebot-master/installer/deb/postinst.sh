#!/bin/sh

# create /bin symlink
ln -s -f /usr/share/filebot/bin/filebot.sh /usr/bin/filebot
