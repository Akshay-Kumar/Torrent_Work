<?php
header('HTTP/1.1 302 Found');
header('Location: https://app.filebot.net/syno/index.json');
?>
