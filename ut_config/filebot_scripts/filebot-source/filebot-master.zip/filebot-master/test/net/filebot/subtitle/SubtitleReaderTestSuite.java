
package net.filebot.subtitle;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ MicroDVDReaderTest.class })
public class SubtitleReaderTestSuite {

}
