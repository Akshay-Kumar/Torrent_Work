﻿using System;
using System.IO;
using System.Reflection;
using System.Diagnostics;

namespace ut_amc_automation
{
    class Program
    {
        static string arguments = string.Empty;
        static StreamWriter writer = null;
        static void Main(string[] args)
        {
            if (args != null)
            {
                if (args.Length > 0)
                {
                    string workingDir = Path.GetDirectoryName(
                    Assembly.GetExecutingAssembly().Location);
                    string logFile = Path.Combine(workingDir, "amc-cmd.log");
                    string batchFile = Path.Combine(workingDir, args[0]);
                    FileStream fs = new FileStream(logFile, FileMode.Append,FileAccess.Write, FileShare.None);
                    writer = new StreamWriter(fs);
                    ProcessStartInfo startInfo = new ProcessStartInfo(batchFile);
                    for (int i = 1; i < args.Length; i++)
                    {
                        arguments += "\"" + NVL(args[i], "") + "\"";
                        arguments += " ";
                    }
                    arguments.Substring(0, arguments.Length - " ".Length);
                    startInfo.Arguments = arguments;
                    startInfo.UseShellExecute = false;
                    startInfo.RedirectStandardOutput = true;
                    startInfo.RedirectStandardError = true;
                    startInfo.CreateNoWindow = true;
                    Process process = new Process();
                    process.StartInfo = startInfo;
                    process.OutputDataReceived += CaptureOutput;
                    process.ErrorDataReceived += CaptureError;
                    process.Start();
                    process.BeginOutputReadLine();
                    process.BeginErrorReadLine();
                    process.WaitForExit();
                }
                else
                {
                    ShowOutput("No arguments passed.", ConsoleColor.Red);
                }
            }
            else
            {
                ShowOutput("No arguments passed.", ConsoleColor.Red);
            }
        }
        static void CaptureOutput(object sender, DataReceivedEventArgs e)
        {
            ShowOutput(e.Data, ConsoleColor.Green);
        }

        static void CaptureError(object sender, DataReceivedEventArgs e)
        {
            ShowOutput(e.Data, ConsoleColor.Red);
        }
        
        static void ShowOutput(string data, ConsoleColor color)
        {
            if (data != null)
            {
                string consoleOutput = string.Format("{0}",data);
                ConsoleColor oldColor = Console.ForegroundColor;
                Console.ForegroundColor = color;
                Console.WriteLine(consoleOutput);
                writer.WriteLine(consoleOutput);
                Console.ForegroundColor = oldColor;
            }
        }

        static string NVL(string input, string replacement)
        {
            if (string.IsNullOrEmpty(input))
                return replacement;
            return input;
        }
    }
}
